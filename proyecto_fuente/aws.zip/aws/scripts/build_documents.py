"""Regenera informe PDF y presentación PPTX a partir del CSV auditado (no AWS)."""
from pathlib import Path
import json, csv, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.lib.colors import HexColor
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, Image, KeepTogether, PageBreak)
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

ROOT=Path(__file__).resolve().parents[1]
DOC=ROOT/'docs'; IMG=ROOT/'diagrams'; DATA=ROOT/'data/local_results/sql_preview'
summary=json.loads((ROOT/'data/local_results/resumen.json').read_text(encoding='utf-8'))

def read(n):
    with (DATA/n).open(encoding='utf-8',newline='') as fp:
        return list(csv.DictReader(fp))
night=read('03_fraude_noche.csv');risk=read('04_fraude_categoria_riesgo.csv')
age=read('05_fraude_edad.csv');months=read('06_fraude_mes.csv');amount=read('02_fraude_por_monto.csv')
WHITE='#ffffff'; NAVY='#152b4b'; BLUE='#2461a1'; TEAL='#17a89d'; LIGHT='#eef5fb'; INK='#162a43'; GREY='#546479'

# Diagramas y gráficos reproducibles para PDF y PowerPoint.
fig,ax=plt.subplots(figsize=(11,7.0));fig.patch.set_facecolor('white');ax.set_xlim(0,11);ax.set_ylim(0,7);ax.axis('off')
labels=[('CSV del usuario','339 607 transacciones · 19 columnas'),('S3 — RAW','CSV privado con cifrado SSE-S3'),('AWS Glue ETL','Validación + minimización + Parquet'),('S3 — CURATED','Partición por fecha de ingesta'),('Glue Crawler + Catalog','Esquema registrado'),('Amazon Athena','8 consultas SQL'),('Streamlit / QuickSight','KPIs y visualizaciones')]
for i,(title,sub) in enumerate(labels):
    y=6.25-i*.86
    box=FancyBboxPatch((1.75,y-.18),7.5,.67,boxstyle='round,pad=0.13',facecolor=LIGHT if i%2 else '#e4f6f5',edgecolor=TEAL if i%2==0 else BLUE,lw=1.5)
    ax.add_patch(box)
    ax.text(5.5,y+.24,title,ha='center',va='center',fontsize=12.7,color=NAVY,weight='bold')
    ax.text(5.5,y-.02,sub,ha='center',va='center',fontsize=9.3,color=GREY)
    if i<6:ax.add_patch(FancyArrowPatch((5.5,y-.31),(5.5,y-.60),arrowstyle='-|>',mutation_scale=16,color=TEAL,lw=1.8))
ax.text(5.5,.15,'SEGURIDAD TRANSVERSAL: IAM/MFA  ·  S3 privado  ·  AWS Budgets  ·  Cost Explorer',ha='center',fontsize=9.8,color=NAVY,weight='bold')
fig.savefig(IMG/'arquitectura.png',dpi=160,bbox_inches='tight');fig.savefig(IMG/'arquitectura.svg',bbox_inches='tight');plt.close(fig)

def barchart(name, rows, lab, labels, colorset=None):
    fig,ax=plt.subplots(figsize=(9,4.2));fig.patch.set_facecolor('white')
    ys=[float(r['tasa_fraude_pct']) for r in rows]
    cs=colorset or [BLUE,TEAL]*max(1,len(rows))
    bars=ax.bar(labels,ys,color=cs[:len(rows)],width=.57)
    for b,n in zip(bars,ys):ax.annotate(f'{n:.3f}%',(b.get_x()+b.get_width()/2,b.get_height()),ha='center',xytext=(0,5),textcoords='offset points',fontsize=9)
    ax.set_ylabel('Tasa de fraude (%)',fontsize=10,color=INK);ax.set_title(lab,fontsize=14,color=NAVY,weight='bold',pad=16)
    ax.set_ylim(0,max(ys)*1.25 if ys else 1);ax.spines[['top','right']].set_visible(False);ax.tick_params(axis='x',labelsize=9)
    fig.tight_layout();fig.savefig(IMG/name,dpi=155,bbox_inches='tight');plt.close(fig)

barchart('tasas_noche.png',night,'Tasa observada: noche frente a no noche',['No noche','Noche'])
barchart('tasas_riesgo.png',risk,'Tasa observada por categoría de alto riesgo',['No marcada','Marcada'])
barchart('tasas_edad.png',age,'Fraude por grupo etario',[r['edad_grupo'] for r in age])

# PDF
regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'; bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
if Path(regular).exists():
    pdfmetrics.registerFont(TTFont('DejaVu',regular));pdfmetrics.registerFont(TTFont('DejaVuBold',bold))
    ff='DejaVu';fb='DejaVuBold'
else:ff='Helvetica';fb='Helvetica-Bold'
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleFC',fontName=fb,fontSize=22,leading=28,textColor=HexColor(NAVY),spaceAfter=13))
styles.add(ParagraphStyle(name='H1FC',fontName=fb,fontSize=15,leading=20,textColor=HexColor(NAVY),spaceBefore=14,spaceAfter=8))
styles.add(ParagraphStyle(name='H2FC',fontName=fb,fontSize=11.8,leading=16,textColor=HexColor(BLUE),spaceBefore=11,spaceAfter=5))
styles.add(ParagraphStyle(name='BodyFC',fontName=ff,fontSize=9.1,leading=14.8,textColor=HexColor(INK),spaceAfter=7))
styles.add(ParagraphStyle(name='SmallFC',fontName=ff,fontSize=7.8,leading=11.5,textColor=HexColor(GREY),spaceAfter=6))
styles.add(ParagraphStyle(name='HeadTable',fontName=fb,fontSize=8.2,leading=11,textColor=colors.white))
styles.add(ParagraphStyle(name='CellTable',fontName=ff,fontSize=8.0,leading=12,textColor=HexColor(INK)))
story=[]
P=lambda text,sty='BodyFC':Paragraph(text,styles[sty])

def section(t):
    if t.startswith(('3. Arquitectura','5. Resultados','7. Costos','8. Conclusiones')):
        story.append(PageBreak())
    story.append(P(t,'H1FC'))
def h2(t):story.append(P(t,'H2FC'))
def para(t):story.append(P(t))
def table(data,widths=None):
    cells=[[P(str(x),'HeadTable' if i==0 else 'CellTable') for x in row] for i,row in enumerate(data)]
    T=Table(cells,colWidths=widths,hAlign='LEFT',repeatRows=1)
    T.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor(NAVY)),('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#f4f8fc'),colors.white]),('BOTTOMPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,-1),(-1,-1),.6,HexColor('#d7e3ef'))]))
    story.append(T);story.append(Spacer(1,9))
def img(path,width=16.3):
    from PIL import Image as PILImage
    pic=PILImage.open(path);ratio=pic.height/pic.width
    story.append(Image(str(path),width=width*cm,height=width*cm*ratio))
    story.append(Spacer(1,8))

story += [Spacer(1,1.2*cm),P('TRABAJO INTEGRADOR · BIG DATA Y CLOUD COMPUTING','H2FC'),
          P('Pipeline de análisis de fraude<br/>con tarjetas de crédito en AWS','TitleFC'),
          P('Informe técnico basado en el CSV procesado proporcionado por el usuario'),
          Spacer(1,12)]
table([['Indicador verificable','Resultado local'],['Registros recibidos','339 607'],['Columnas / campos vacíos','19 / 0'],['Transacciones fraudulentas','1 782'],['Tasa de fraude','0,5247 %'],['Fecha de sustentación','18 y 19 de noviembre de 2026 · 8:00 p.m.']],widths=[7.8*cm,8.4*cm])
para('<b>Alcance real:</b> código AWS, dataset incluido, chequeo local, consultas y dashboard preparados. <b>No se ha ejecutado el despliegue en una cuenta AWS</b>; capturas y costos reales deben producirse allí.')
para('<b>Fuente declarada:</b> Kaggle, dhruvb2028/credit-card-fraud-dataset; el archivo recibido es un CSV procesado cuya correspondencia exacta con Kaggle no se puede verificar con los materiales disponibles.')
story.append(PageBreak())
section('1. Contexto y problema')
para('El objetivo es analizar qué segmentos de un conjunto de transacciones procesadas muestran una mayor tasa observada de fraude y demostrar una arquitectura académica replicable de ingesta, transformación y consulta de datos en AWS. Se responde a la rúbrica del curso mediante S3, Glue, Data Catalog, Athena, IAM y AWS Budgets; QuickSight es opcional.')
section('2. Descripción y evaluación de la data')
table([['Aspecto','Dato observado'],['Archivo','fraude_tarjeta_credito_process.csv'],['Tamaño del archivo','54 012 105 bytes (aprox. 54,0 MB)'],['Filas / columnas','339 607 / 19'],['Filas válidas / rechazadas','339 607 / 0'],['Clase minoritaria','1 782 fraudes = 0,5247 %'],['SHA-256','3f7762e0f7c35824e00aeb91968a3fc724c6e2a2f87bfd1d6c37277977cba794']],widths=[4.9*cm,11.3*cm])
h2('Grupos de variables')
para('<b>Objetivo:</b> es_fraude. <b>Magnitud transformada:</b> monto_winsorizado_99, monto_log, monto_percentil_categoria y monto_vs_categoria. <b>Perfil:</b> edad_cliente y edad_grupo. <b>Distancia:</b> distancia_cliente_comercio_km y distancia_log. <b>Contexto temporal:</b> hora_sin, hora_cos, es_noche, es_fin_de_semana, es_fin_de_semana_noche, mes y dia. <b>Riesgo:</b> es_noche_high_risk, high_risk_cat y poblacion_ciudad.')
para('No se dispone de marca de tiempo completa ni año, importe monetario original, moneda, ID de operación o descripción de categoría comercial. La etiqueta high_risk_cat es binaria (0/1), no una lista de comercios. La edad precisa y el tamaño de ciudad se excluyen de curated por minimización.')
section('3. Arquitectura propuesta y justificación')
img(IMG/'arquitectura.png',15.8)
para('S3 RAW conserva el CSV privado; Glue Spark aplica tipos y filtros y escribe Parquet Snappy en CURATED; Glue Crawler genera la tabla en Data Catalog; Athena consulta el dataset columnar. IAM, cifrado SSE-S3, TLS, presupuesto y ciclo de vida cubren los controles transversales. Un panel Streamlit muestra agregados locales o exportados de Athena, claramente separados.')
section('4. Implementación técnica reproducible')
table([['Etapa','Ejecución local/AWS'],['Validación local','python scripts/local_check.py --csv data/real/fraude_tarjeta_credito_process.csv'],['Despliegue','python scripts/run_aws.py deploy --email correo@ejemplo.com'],['Subida CSV','python scripts/run_aws.py upload --data data/real/fraude_tarjeta_credito_process.csv'],['Transformar','python scripts/run_aws.py etl'],['Catálogo y consultas','python scripts/run_aws.py catalog ; python scripts/run_aws.py queries'],['Panel','python -m streamlit run dashboard/app.py']],widths=[4.3*cm,11.9*cm])
para('El ETL considera válidas las etiquetas binarias y los rangos de mes, día, monto no negativo, percentil y distancia. Un conjunto cerrado de 13 campos analíticos se escribe a Parquet, particionado por ingest_date. La conversión solo puede verificarse en AWS ejecutando Glue.')
section('5. Resultados del análisis local del CSV')
para('La tasa global verificada es <b>0,5247 %</b> (1 782/339 607): la clase fraudulenta representa una pequeña fracción de los registros. La comparación entre segmentos debe usar tasas por grupo, no únicamente conteos absolutos.')
img(IMG/'tasas_noche.png',15.5)
para(f'Entre registros con <b>es_noche=1</b> se observan {int(night[1]["fraudes"]):,} fraudes en {int(night[1]["transacciones"]):,} transacciones ({float(night[1]["tasa_fraude_pct"]):.4f} %); con es_noche=0, {int(night[0]["fraudes"]):,} de {int(night[0]["transacciones"]):,} ({float(night[0]["tasa_fraude_pct"]):.4f} %). Esto es asociación dentro de la muestra, no prueba de causalidad.'.replace(',',' '))
img(IMG/'tasas_riesgo.png',15.5)
para(f'La categoría marcada como alto riesgo (high_risk_cat=1) presenta {float(risk[1]["tasa_fraude_pct"]):.4f} % de fraudes, frente a {float(risk[0]["tasa_fraude_pct"]):.4f} % cuando es 0. No hay categorías comerciales descriptivas en el CSV.')
img(IMG/'tasas_edad.png',15.5)
para('En grupos etarios también hay diferencias descriptivas; las decisiones de negocio deben considerar tamaño del grupo, clase desbalanceada y posible sesgo de muestreo. No se ha entrenado ningún algoritmo predictivo.')
section('6. Ocho consultas de Athena')
table([['Consulta','Pregunta que responde'],['01 KPIs','Volumen, fraudes, tasa y suma de monto transformado'],['02 Rangos monto','¿En qué rangos de monto winsorizado se observa más fraude?'],['03 Noche','¿Cómo cambia la tasa según el indicador es_noche?'],['04 Alto riesgo','¿Cómo cambia la tasa según high_risk_cat?'],['05 Edad','¿Qué grupos de edad presentan diferente tasa?'],['06 Mes','¿Cómo se distribuye el fraude por mes (sin año)?'],['07 Fin de semana','¿Hay diferencia según es_fin_de_semana?'],['08 Distancia','¿Cómo varía la tasa por distancia entre cliente y comercio?']],widths=[5.2*cm,11*cm])
para('Las vistas reproducidas en data/local_results/sql_preview se computaron con Python y <b>no son evidencia de Athena</b>. Las consultas bajo sql/ se ejecutan contra Athena una vez creado el catálogo.')
section('7. Costos, seguridad y gobernanza')
para('El CSV fuente ocupa aprox. 0,054 GB (decimal); para experimentos se puede presupuestar una fracción de GB de S3 más archivos Parquet y resultados. El costo dominante suele depender de los minutos de Glue Spark/Crawler; S3 y Athena varían con volumen y escaneo.')
table([['Supuesto orientativo','Tarifa usada (NO verificada en factura)'],['S3 Standard','USD 0,023 por GB-mes'],['Glue Spark y Crawler','USD 0,44 por DPU-hora'],['Athena SQL bajo demanda','USD 5 por TB escaneado']],widths=[7*cm,9.2*cm])
para('Ejemplo laboratorio de 2 DPUs x 10 min Glue + 1 DPU x 10 min Crawler + 0,1 GB S3 y 0,01 TB Athena ≈ USD 0,273; estimación simplificada sin solicitudes, logs, impuestos, red, mínimos ni licencias. Los valores no son cargos reales: validar en AWS Pricing Calculator y registrar Cost Explorer tras desplegar. AWS Budgets no impide el consumo.')
para('Gobernanza: MFA de la identidad, rol de servicio para Glue, permisos por prefijo, S3 privado con SSE-S3 y denegación de HTTP, vencimiento de RAW/CURATED/resultados y separación del dato procesado. El RAW requiere revisión de privacidad. Guardar hash y cadena de custodia del archivo del usuario.')
section('8. Conclusiones, limitaciones y trabajos futuros')
for x in [
    'La fuente procesada cumple el umbral sugerido: 339 607 filas válidas, sin nulos y con etiqueta 0/1; el desbalance obliga a comparar tasas.',
    'Se observan asociaciones entre es_noche, high_risk_cat y fraude, pero no se demuestra causalidad ni utilidad de una regla automática.',
    'La infraestructura como código y las consultas están listas para ejecutar; falta evidencia del despliegue AWS real y costos incurridos.',
    'La winsorización impide calcular sumas financieras originales; no existe período completo ni categorías descriptivas.',
    'Futuro: contrastar el CSV con el origen Kaggle, añadir linaje, tests en Glue, monitoreo, protección granular y evaluación de modelo solo con datos validados.'
]:para('• '+x)
section('9. Referencias (formato IEEE)')
for ref in [
    '[1] Curso Big Data y Cloud Computing, “Trabajo integrador: Big data y Cloud Computing”, documento de consigna, 2026.',
    '[2] D. B., “Credit Card Fraud Dataset”, Kaggle, https://www.kaggle.com/datasets/dhruvb2028/credit-card-fraud-dataset (referencia declarada; relación con CSV procesado sin verificar).',
    '[3] Amazon Web Services, “AWS Glue Documentation”, https://docs.aws.amazon.com/glue/.',
    '[4] Amazon Web Services, “Amazon Athena Documentation”, https://docs.aws.amazon.com/athena/.',
    '[5] Amazon Web Services, “AWS Pricing Calculator”, https://calculator.aws/.'
]:para(ref)
para('<b>Anexos en ZIP:</b> scripts Glue, infraestructura, 8 consultas SQL, reporte JSON de calidad, CSV originales, Dashboard, guía de presupuesto y lista de evidencias AWS pendientes.')

pdfpath=DOC/'informe_tecnico.pdf'
doc=SimpleDocTemplate(str(pdfpath),pagesize=(595.28,841.89),rightMargin=42,leftMargin=42,topMargin=56,bottomMargin=48,title='FraudCloud 2026 | Informe técnico',author='Proyecto académico')
def canvas_page(canvas,doc):
    canvas.saveState();w,h=doc.pagesize
    canvas.setStrokeColor(HexColor(TEAL));canvas.setLineWidth(2);canvas.line(42,h-36,w-42,h-36)
    canvas.setFont(ff,8);canvas.setFillColor(HexColor(GREY));canvas.drawString(42,25,'FraudCloud 2026 · Datos procesados aportados por el usuario')
    canvas.drawRightString(w-42,25,f'Página {doc.page}')
    canvas.restoreState()
doc.build(story,onFirstPage=canvas_page,onLaterPages=canvas_page)

# PPTX
ppt=Presentation();ppt.slide_width= Inches(13.333);ppt.slide_height=Inches(7.5)
BG=RGBColor(248,251,255); C_NAVY=RGBColor(21,43,75); C_TEAL=RGBColor(23,168,157);C_BLUE=RGBColor(36,97,161);C_GREY=RGBColor(84,100,121)

def rect(sl,x,y,w,h,fill,radius=False):
    sh=sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h))
    sh.fill.solid();sh.fill.fore_color.rgb=fill;sh.line.fill.background();return sh

def text(sl,txt,x,y,w,h,size=20,color=C_NAVY,bold=False):
    tb=sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf=tb.text_frame;tf.word_wrap=True
    tf.margin_left=Pt(2);tf.margin_top=Pt(2)
    for i,line in enumerate(txt.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=line;p.font.name='Aptos';p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=color;p.space_after=Pt(10)
    return tb

def slide(title,sub=None):
    s=ppt.slides.add_slide(ppt.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=BG
    rect(s,0,0,13.333,.17,C_TEAL);text(s,title,.72,.48,11.9,.67,27,C_NAVY,True)
    if sub:text(s,sub,.74,1.20,11.9,.52,12,C_GREY)
    rect(s,.72,7.09,11.95,.013,C_TEAL)
    text(s,'Big Data y Cloud Computing  |  FraudCloud 2026',.74,7.13,9,.27,9,C_GREY)
    text(s,str(len(ppt.slides)).zfill(2),12.0,7.12,.5,.25,9,C_GREY)
    return s

def bulletlist(s,ls,x=.86,y=1.7,w=11.8,size=19,line=0.82):
    for i,t in enumerate(ls):
        rect(s,x,y+i*line+.10,.10,.10,C_TEAL,True)
        text(s,t,x+.25,y+i*line,w-.25,line-.04,size,C_NAVY)

def imgslide(s,path,x,y,w):
    s.shapes.add_picture(str(path),Inches(x),Inches(y),width=Inches(w))

def chip(s,label,val,x,w):
    rect(s,x,2.05,w,1.45,RGBColor(231,242,251),True)
    text(s,label,x+.17,2.24,w-.2,.45,13,C_GREY)
    text(s,val,x+.16,2.68,w-.2,.58,29,C_NAVY,True)

s=slide('FraudCloud 2026','Diseño e implementación de un pipeline de Big Data en AWS para analizar fraude con tarjetas')
text(s,'TRABAJO INTEGRADOR',.9,2.25,9,.45,17,C_TEAL,True)
text(s,'Datos reales aportados por el usuario · 339 607 transacciones',.9,3.05,11.4,1,31,C_NAVY,True)
text(s,'S3  →  Glue  →  Parquet  →  Data Catalog  →  Athena  →  Dashboard',.9,4.5,11.4,1,20,C_BLUE)
text(s,'Sustentación: 18 y 19 de noviembre de 2026',.9,6.15,11,.45,15,C_GREY)

s=slide('01 · Problema y alcance','Análisis de fraude sin depender de una aplicación de pagos productiva')
bulletlist(s,['Objetivo: comparar tasas observadas de fraude entre segmentos de transacciones.',
              'Fuente operativa: CSV procesado proporcionado por el usuario.',
              'Proyecto académico de analítica por lotes, NO detector predictivo.',
              'AWS listo para desplegar; evidencia de ejecución real aún pendiente.'])

s=slide('02 · Dataset auditado','No se confunden registros transformados con importes monetarios originales')
chip(s,'Transacciones','339 607',.8,2.72);chip(s,'Fraudes','1 782',3.8,2.72);chip(s,'Tasa','0,5247 %',6.8,2.72);chip(s,'Variables','19',9.8,2.72)
bulletlist(s,['Sin valores vacíos ni filas rechazadas en la comprobación local.',
             'Columna objetivo: es_fraude (0 legítima; 1 fraude).',
             'Monto winsorizado: variable estadística; no pérdida monetaria real.'],.91,4.15,11.8,17,.72)

s=slide('03 · Arquitectura AWS','Servicios obligatorios y opción de visualización')
imgslide(s,IMG/'arquitectura.png',2.9,1.63,7.0)

s=slide('04 · Implementación Glue y Parquet','13 variables curated; se excluyen edad exacta y población de ciudad')
bulletlist(s,['S3 RAW contiene CSV con acceso privado, SSE-S3 y TLS.',
              'Glue ETL valida etiquetas 0/1, montos, percentil, fechas parciales y grupos de edad.',
              'Salida Parquet comprimido Snappy y particionado por fecha de ingesta.',
              'Crawler detecta tabla para consultas Athena en el catálogo.',
              'El origen conserva 19 campos; CURATED proyecta solo atributos necesarios.'],.9,1.65,11.8,18,.8)

s=slide('05 · Hallazgo: fraude nocturno','Diferencia descriptiva dentro de la muestra, no causalidad')
imgslide(s,IMG/'tasas_noche.png',1.7,1.6,9.8)
text(s,'Noche: 1 530/79 502 (1,9245 %)  ·  No noche: 252/260 105 (0,0969 %)',.95,6.58,11.8,.38,15,C_NAVY,True)

s=slide('06 · Hallazgo: categoría de riesgo','high_risk_cat es indicador 0/1; no identifica comercios')
imgslide(s,IMG/'tasas_riesgo.png',1.7,1.57,9.8)
text(s,'Categoría marcada: 1,3564 %  ·  No marcada: 0,2849 %',1.1,6.58,11.3,.38,15,C_NAVY,True)

s=slide('07 · Análisis por edad y monto','Comparar tasas normalizadas, no solo la cantidad de casos')
imgslide(s,IMG/'tasas_edad.png',.8,1.54,8.8)
rect(s,9.7,2.25,2.7,2.7,RGBColor(231,242,251),True)
text(s,'Monto winsorizado',9.93,2.55,2.3,.65,15,C_NAVY,True)
text(s,'Agrupación por rangos estadísticos, sin moneda ni importe original.',9.93,3.35,2.3,1.43,13,C_GREY)

s=slide('08 · Ocho preguntas para Athena','Archivos SQL individuales y exportación CSV por consulta')
bulletlist(s,['01  KPIs globales       02  Fraude por rango de monto winsorizado',
              '03  Fraude por noche       04  Bandera de categoría de riesgo',
              '05  Fraude por edad         06  Distribución mensual (sin año)',
              '07  Fin de semana           08  Fraude por distancia comercial'],.88,1.9,11.7,18,.9)
text(s,'Las vistas data/local_results/sql_preview son locales; no constituyen evidencia de Athena.',.9,6.10,11.6,.65,14,C_GREY)

s=slide('09 · Seguridad y presupuesto','Control de costos desde el primer día')
bulletlist(s,['IAM + MFA para usuarios; rol específico de Glue y acceso restringido.',
              'S3 privado con SSE-S3, TLS obligatorio y ciclo de vida definido.',
              'AWS Budgets configurado con correo (no bloquea consumos).',
              'Costos referenciales sujetos a Pricing Calculator; Cost Explorer real pendiente.',
              'QuickSight solo opcional para evitar cargos sin autorización.'],.93,1.68,11.7,18,.83)

s=slide('10 · Cómo demostrar el proyecto','Comandos reproducibles dentro de la carpeta del ZIP')
bulletlist(s,['python scripts/local_check.py --csv data/real/fraude_tarjeta_credito_process.csv',
              'python scripts/run_aws.py deploy --email correo@ejemplo.com',
              'python scripts/run_aws.py upload --data data/real/fraude_tarjeta_credito_process.csv',
              'python scripts/run_aws.py etl  →  catalog  →  queries',
              'python -m streamlit run dashboard/app.py'],.9,1.58,12.1,16,.92)
text(s,'Capturar S3, Glue SUCCEEDED, Catalog, Athena y Cost Explorer tras ejecutar en la cuenta AWS.',.9,6.39,11.7,.55,13,C_GREY)

s=slide('11 · Conclusiones y limitaciones','El análisis es verificable en CSV; la operación AWS queda para el despliegue')
bulletlist(s,['339 607 registros procesados y 1 782 etiquetas de fraude (0,5247 %).',
              'Mayores tasas asociadas a es_noche=1 y high_risk_cat=1.',
              'Resultados descriptivos; no se infieren causas ni se entrena ML.',
              'Faltan importe original, moneda, timestamp completo y linaje verificable.',
              'Pipeline y documentación preparados para demostración en AWS.'],.95,1.67,11.8,17.5,.88)

ppt.save(str(DOC/'presentacion_sustentacion.pptx'))
print('Informe:',pdfpath,'pptx:',DOC/'presentacion_sustentacion.pptx', 'slides:',len(ppt.slides))
