"""Validaciones ejecutables sin credenciales ni costos de AWS."""
import csv
import json
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REAL=ROOT/'data/real/fraude_tarjeta_credito_process.csv'


def test_archivo_real_presente_y_esquema():
    with REAL.open(encoding='utf-8',newline='') as f:
        r=csv.DictReader(f)
        assert {'es_fraude','monto_winsorizado_99','es_noche','edad_grupo','high_risk_cat','mes'} <= set(r.fieldnames)
        assert len(r.fieldnames)==19
        assert sum(1 for _ in r)==339_607


def test_checker_audita_csv_real(tmp_path):
    p=subprocess.run([sys.executable,str(ROOT/'scripts/local_check.py'),'--csv',str(REAL),'--outdir',str(tmp_path)],capture_output=True,text=True)
    assert p.returncode==0,p.stderr
    d=json.loads((tmp_path/'resumen.json').read_text(encoding='utf-8'))
    assert (d['filas_raw'],d['validas'],d['invalidas'],d['fraudes'],d['legitimas']) == (339607,339607,0,1782,337825)
    assert d['sha256']=='3f7762e0f7c35824e00aeb91968a3fc724c6e2a2f87bfd1d6c37277977cba794'
    q=list((tmp_path/'sql_preview').glob('*.csv'))
    assert len(q)==8
    with (tmp_path/'sql_preview/03_fraude_noche.csv').open(newline='') as f:
        night={int(r['es_noche']):r for r in csv.DictReader(f)}
    assert night[1]['fraudes']=='1530' and night[0]['fraudes']=='252'


def test_sql_and_glue_match_real_schema():
    sql=list((ROOT/'sql').glob('*.sql'))
    assert len(sql)==8
    assert all('{{DATABASE}}' in p.read_text() and '{{TABLE}}' in p.read_text() for p in sql)
    assert 'monto_winsorizado_99' in (ROOT/'glue/glue_etl.py').read_text()
    assert 'es_fraude' in (ROOT/'scripts/run_aws.py').read_text()
    assert 'data/real/fraude_tarjeta_credito_process.csv' in (ROOT/'README.md').read_text()
