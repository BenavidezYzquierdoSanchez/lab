# Hipótesis de costos — consultar calculadora y consola AWS

**No son facturas, tarifas verificadas en noviembre de 2026 ni resultados de AWS Cost Explorer.** Tarifas orientativas de ejemplo (us-east-1, verificar oferta/región/fecha/cuenta): S3 Standard 0,023 USD/GB-mes; Glue Spark y Crawler 0,44 USD/DPU-hora; Athena 5 USD/TB escaneado.

El archivo real tiene 54 012 105 bytes (~0,054 GB decimal). El escenario laboratorio de `presupuesto_costos.csv` modela 0,1 GB S3, un ETL de 2 DPUs durante 10 min, un crawler de 1 DPU durante 10 min y 0,01 TB de consulta: subtotal teórico aproximado USD 0,2723.

No incluye mínimos facturables, solicitudes S3, logs CloudWatch, transferencia, IVA, dimensiones de QuickSight, otras tarifas ni retención extendida. **AWS Budgets no apaga los servicios ni limita gasto.** Estime de nuevo con AWS Pricing Calculator y capture consumo real en Cost Explorer cuando ejecute el pipeline.

Proyección de escala: tabla `docs/presupuesto_costos.csv`; los escenarios 100 GB y 1000 GB son hipotéticos y no proyectan el costo real de un workload concreto.

Fuentes oficiales a verificar: https://calculator.aws/ · https://aws.amazon.com/s3/pricing/ · https://aws.amazon.com/glue/pricing/ · https://aws.amazon.com/athena/pricing/
