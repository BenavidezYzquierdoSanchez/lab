# Gobernanza, seguridad y mínimo privilegio — CSV procesado recibido

## Identidad y accesos

1. Para la consola y CLI, preferir IAM Identity Center con MFA. No usar root ni publicar secretos de AWS.
2. `infra/main.yaml` crea un rol de servicio **GlueExecutionRole** con permisos de lectura RAW y escritura CURATED en el bucket del proyecto; además emplea la política administrada `AWSGlueServiceRole`, que debe auditarse si se pretende uso de producción.
3. Configure por separado identidad del operador de CloudFormation; para lectura analítica permitir Athena (`StartQueryExecution`, `GetQueryExecution`, `GetQueryResults`), catálogo Glue y resultados S3 únicamente donde sea necesario. Una política ejemplo no reemplaza la validación en IAM Policy Simulator.
4. Los analistas deben acceder a curated, no a RAW; evitar exponer el prefijo de datos fuente como repositorio público.

## Datos y minimización

El CSV contiene variables derivadas pero no se dispone de prueba del procesamiento original. Las columnas **`edad_cliente`** (edad precisa) y **`poblacion_ciudad`** (cuasi-identificador de localidad) solo quedan en RAW; la salida curated conserva el grupo etario y otros 12 atributos analíticos. El CSV no muestra nombres, números de tarjeta, SSN ni direcciones explícitas, pero es imprescindible revisar el dato RAW antes de usarlo fuera del laboratorio.

Protección en la plantilla: bucket con S3 Public Access Block, cifrado SSE-S3, política TLS obligatoria; ciclos de vida RAW 90 días, CURATED 180 días y Athena results 7 días. Los permisos S3 del trabajo deben revisarse con el principio de mínimo privilegio; el cifrado no sustituye controles de identidad.

## Interpretación de los indicadores

- `monto_winsorizado_99`: importe estadísticamente recortado por el nombre del campo; no considerar total como monto robado.
- `high_risk_cat`: etiqueta binaria de riesgo; no describir sectores o negocios específicos.
- `mes`, `dia`: sin año de observación, no permiten calcular tendencias interanuales ni fechar incidentes.
- `hora_sin`, `hora_cos` y `es_noche`: horario transformado; las consultas usan `es_noche` y no inventan una fecha/hora original.
- La clase `es_fraude` está muy desbalanceada; los patrones describen la muestra y no prueban relaciones causales o rendimiento de un modelo.

## Riesgos operativos

| Riesgo | Mitigación |
|---|---|
| Costos por ejecución reiterada | Budget con alertas, Glue 2 workers, límite 1 GiB de escaneo Athena por consulta, cleanup tras demo |
| Exposición de datos | S3 privado, TLS, MFA, roles restringidos; no exponer RAW |
| Interpretación monetaria errónea | Informes etiquetan explícitamente `monto_winsorizado_99` como proxy |
| Uso de datos sin procedencia íntegra | Guardar CSV con checksum, registrar fuente como usuario y verificar contra Kaggle si se requiere |
| Resultados locales confundidos con AWS | Directorios separados `local_results/sql_preview/` y `athena_results/` |
| Sustentación sin implementación | Reunir capturas **reales** y Cost Explorer después de desplegar |
