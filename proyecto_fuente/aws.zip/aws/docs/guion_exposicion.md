# Guion — 12 minutos + 5 minutos de preguntas

**00:00–02:00 — problema/datos.** Big Data para conocer patrones de fraude, fuente de datos procesados aportada por el usuario, 339 607 filas y 19 columnas, 1 782 fraudes (0,5247 %). Advertir que el monto está winsorizado, no es valor financiero original.

**02:00–05:00 — arquitectura AWS.** Mostrar Draw.io: almacenamiento S3 RAW/Curated, Glue Spark para validación/Parquet, Crawler, Catálogo, Athena, visualización opcional y seguridad/costos.

**05:00–09:00 — demostración.** Mostrar lectura de CSV y agregados locales; si AWS ya está desplegado, abrir S3, Glue Job SUCCEEDED, Parquet, Glue Data Catalog y 3 consultas de Athena (noche, alto riesgo, edad). Si no se ha desplegado, explicar abiertamente que no constituye evidencia de implementación AWS.

**09:00–11:00 — costos/seguridad.** Budget y alertas, costos reales desde Cost Explorer **cuando existan**. Costos proyectados basados en supuestos. MFA y mínimo privilegio; RAW restringido, curated solo atributos necesarios.

**11:00–12:00 — hallazgos/limitaciones.** Desbalance 0,525 %. Noche: 1,9245 % con `es_noche=1`, frente a 0,0969 % cuando es 0. Asociación observacional, no causalidad. El archivo no incluye fecha completa, importes originales, moneda ni categoría textual.

**12:00–17:00 — preguntas.** Por qué Parquet, diferencia RAW/curated, costo Glue/Athena, cómo controlar clase minoritaria, qué no se puede inferir del origen procesado.
