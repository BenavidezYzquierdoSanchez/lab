# Guía de visualización opcional con QuickSight / Amazon Quick

**No incluido como recurso creado:** puede requerir suscripción/costo y autorización de acceso. El trabajo permite visualización opcional.

1. Ejecutar con éxito Glue ETL, crawler y Athena usando `data/real/fraude_tarjeta_credito_process.csv`.
2. En la consola de QuickSight, permitir acceso al catálogo, Athena y bucket S3 (`curated/` y `athena-results/`) según la configuración de la cuenta.
3. Crear origen Athena con workgroup y base de datos informados por `python scripts/run_aws.py status`.
4. Crear 3 visuales sugeridos: KPI `COUNT(es_fraude)`, `SUM(es_fraude)` y `SUM(es_fraude)/COUNT(*)*100`; barras de `es_noche` por tasa; barras de `high_risk_cat` por tasa.
5. Puede usar las consultas `sql/01_kpis_fraude.sql`, `sql/03_fraude_noche.sql`, `sql/04_fraude_categoria_riesgo.sql` sustituyendo `{{DATABASE}}` y `{{TABLE}}` por identificadores reales. Para una vista tabla QuickSight, use la tabla en Glue Catalog.
6. Documentar región, edición, usuarios, costo y capturas; nunca afirmar disponibilidad/costo sin verificar en consola.

**Cuidado**: `high_risk_cat` es un indicador 0/1, no categoría comercial; `monto_winsorizado_99` está truncado y no corresponde a pérdida monetaria real. Streamlit permite previsualizar localmente sin QuickSight, pero no equivale a él.
