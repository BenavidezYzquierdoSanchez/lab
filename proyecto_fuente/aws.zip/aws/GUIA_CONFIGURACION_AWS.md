# Guía de despliegue de FraudCloud 2026 en AWS (Windows + VS Code)

> **Seguridad y costo:** usar MFA, identidad individual autorizada (no root), cuenta/región controladas. AWS Budgets alerta, **no establece un límite de gasto**. No publicar claves ni dataset en repositorios públicos. Consulte facturación y créditos de su cuenta antes de activar servicios o AWS Organizations.

## 0. Descargar y abrir

Descomprimir ZIP. En Visual Studio Code: Archivo > Abrir carpeta > `aws_fraude_tarjetas_2026_REAL`. Ejecutar los siguientes comandos **dentro de esa carpeta**, desde Terminal > Nueva terminal (PowerShell).

Requisitos instalados: Python >=3.10; AWS CLI v2; permisos para CloudFormation, IAM, Glue, S3, Athena, Budgets. Glue 5.0 y 2 trabajadores G.1X generan cargos al ejecutarse.

```powershell
python --version
aws --version
python -m pip install -r requirements.txt
```

## 1. Identidad AWS

Si su organización ha configurado IAM Identity Center (SSO), ejecute:

```powershell
aws configure sso
aws sso login --profile fraudlab
$env:AWS_PROFILE = "fraudlab"
aws sts get-caller-identity
```

Cuando el asistente pregunte, elija `fraudlab` como nombre del perfil y `us-east-1` como región principal. El portal/start URL y rol deben ser los que su cuenta u organización realmente proporciona. Si usa un perfil `default` ya configurado, omita `$env:AWS_PROFILE` y las instrucciones para SSO. No cree access keys de root.

> Nota: habilitar AWS Organizations en una cuenta Free Tier puede cambiar el modelo de facturación; revíselo en la documentación actual de AWS antes de hacerlo.

## 2. Presupuesto y verificación

Crear un Budget en AWS Billing para alertas desde el primer día; la plantilla también crea uno de USD 5 de forma predeterminada. Verificar que `get-caller-identity` muestre la cuenta correcta. Comprobar la plantilla:

```powershell
aws cloudformation validate-template --template-body file://infra/main.yaml --region us-east-1
python scripts/local_check.py --csv data/real/fraude_tarjeta_credito_process.csv
```

La base Glue se crea como `fraude_tarjetas_db` (Athena admite letras, números y guiones bajos).

## 3. Aprovisionar con CloudFormation

Reemplazar el correo de ejemplo (no copiarlo literalmente):

```powershell
python scripts/run_aws.py deploy --region us-east-1 --email TU_CORREO@DOMINIO.COM --budget 5
python scripts/run_aws.py status --region us-east-1
```

Esperar a `CREATE_COMPLETE` en AWS > CloudFormation > Stacks > `fraude-tarjetas-lab`. Si falla, abrir la pestaña **Events** para identificar el recurso y el mensaje de error exactos. El script confirma la creación de un rol IAM con nombre (`CAPABILITY_NAMED_IAM`).

## 4. Cargar los datos en S3 y ejecutar Glue

```powershell
python scripts/run_aws.py upload --region us-east-1 --data data/real/fraude_tarjeta_credito_process.csv
python scripts/run_aws.py etl --region us-east-1
```

Revisar AWS S3: bucket `fraude-tarjetas-<ID_CUENTA>-us-east-1`, objeto en `raw/transactions/`; revisar `curated/transactions/` con archivos Parquet tras Glue `SUCCEEDED`. AWS Glue > ETL jobs > `fraude-tarjetas-etl` > Runs; si falla, abrir los logs CloudWatch desde el run.

## 5. Catalogar y ejecutar Athena

```powershell
python scripts/run_aws.py catalog --region us-east-1
python scripts/run_aws.py queries --region us-east-1
```

Comprobar AWS Glue > Crawlers > `fraude-tarjetas-crawler` (`SUCCEEDED`) y Data Catalog > Databases > `fraude_tarjetas_db`; consultar la tabla creada. En Athena, seleccionar workgroup `fraude-tarjetas-wg`, catálogo `AwsDataCatalog`, base `fraude_tarjetas_db`. Los ocho CSV descargados por el script estarán en `data/athena_results/` (no deben confundirse con resultados locales).

## 6. Visualizar en Streamlit (en el PC)

```powershell
python -m pip install -r dashboard/requirements.txt
python -m streamlit run dashboard/app.py
```

Abrir la dirección local que muestre Streamlit (habitualmente `http://localhost:8501`). El tablero incluido es **local**, no está publicado en AWS. QuickSight es opcional; ver `docs/guia_quicksight.md` antes de habilitarlo, pues puede generar costos.

## 7. Evidencias de la rúbrica

Guardar capturas reales de: CloudFormation CREATE_COMPLETE; raw/ y curated/ en S3; Glue job SUCCEEDED; crawler SUCCEEDED; tabla `fraude_tarjetas_db`; consulta Athena y resultados; dashboard; Budgets y Cost Explorer. La cuenta y los costos reales no se han utilizado/verificado desde el ZIP.

## 8. Desmontar al finalizar

**Irreversible**: este comando vacía el bucket de la pila y borra los recursos del stack, incluyendo datos subidos y Parquet generado.

```powershell
python scripts/run_aws.py destroy --region us-east-1 --confirm-destroy
```

Verificar en CloudFormation `DELETE_COMPLETE` y revisar Billing / Cost Explorer. Pueden persistir logs de CloudWatch y otros recursos ajenos al stack.

## Solución de problemas

- `Unable to locate credentials`, `SSO session expired`: confirmar `$env:AWS_PROFILE` y ejecutar `aws sso login --profile fraudlab`.
- `AccessDenied`, `iam:PassRole` o `InsufficientCapabilities`: verificar permisos para crear roles de servicio Glue y CloudFormation. No ampliar permisos sin revisar la acción requerida.
- `CREATE_FAILED`: abrir CloudFormation > Stacks > `fraude-tarjetas-lab` > Events; revisar `ResourceStatusReason`.
- `raw/transactions/ ya tiene datos`: el upload protege de mezclas. No volver a cargar hasta inspeccionar y decidir conscientemente si reemplazar el objeto.
- `Crawler` no crea tabla: verificar primero que Glue ETL finalizó, que existe Parquet en `curated/transactions/`, y que el crawler terminó en `SUCCEEDED`.
- `Athena` database not found: confirmar región `us-east-1`, base `fraude_tarjetas_db`, y esperar el crawler. **No usar una base con guiones**.
- `Athena` permisos insuficientes: revisar workgroup, acceso al bucket de resultados y catálogo Glue del operador.

Documentación oficial: https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-sso.html | https://docs.aws.amazon.com/athena/latest/ug/tables-databases-columns-names.html | https://docs.aws.amazon.com/cost-management/latest/userguide/bcm-lite-create-a-budget.html
