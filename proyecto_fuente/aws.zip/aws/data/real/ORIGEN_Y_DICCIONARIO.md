# Origen y tratamiento de datos

Archivo exacto recibido del usuario: `fraude_tarjeta_credito_process.csv` (CSV procesado, 19 columnas).
Procedencia declarada por el usuario: https://www.kaggle.com/datasets/dhruvb2028/credit-card-fraud-dataset
**No se ha podido verificar que este archivo procesado provenga íntegramente de ese dataset ni reconstruir su proceso de preparación.**
**No incluye fechas completas, ID de transacción, categoría de negocio, importe monetario original ni moneda.**

| Campo original | Significado interpretado | Uso en AWS |
|---|---|---|
| `es_fraude` | Etiqueta binaria 0/1 | KPI objetivo |
| `monto_winsorizado_99` | Monto truncado al percentil 99 (por denominación), sin moneda declarada | Rangos y proxy de magnitud, NO valor contable exacto |
| `monto_log` | Transformación logarítmica de monto | Archivo RAW; omitido de curated |
| `monto_percentil_categoria` | Percentil estimado dentro de categoría, sin etiqueta textual | Descriptivo |
| `monto_vs_categoria` | Relación numérica con la categoría, definición externa no documentada | Descriptivo, no se interpreta como importe |
| `edad_cliente` | Edad numérica | Solo RAW, minimización de datos en curated |
| `edad_grupo` | Grupo etario | Segmentación de riesgo |
| `distancia_cliente_comercio_km` | Distancia calculada en km | Segmentación de riesgo |
| `distancia_log` | Distancia transformada | Solo RAW |
| `hora_sin`, `hora_cos` | Codificación cíclica horaria | Solo RAW; NO se asume que exista timestamp |
| `es_noche` | Indicador binario horario proporcionado | Segmentación |
| `es_fin_de_semana` | Indicador binario proporcionado | Segmentación |
| `es_fin_de_semana_noche` | Indicador derivado | Segmentación opcional |
| `es_noche_high_risk` | Indicador derivado para noche y alto riesgo | Segmentación opcional |
| `high_risk_cat` | Bandera binaria de categoría de alto riesgo | Segmentación, NO etiqueta de categoría comercial |
| `poblacion_ciudad` | Tamaño de población de localidad | Solo RAW (quasi-identificador) |
| `mes`, `dia` | Mes y día sin año | Comparaciones estacionales no series cronológicas |
