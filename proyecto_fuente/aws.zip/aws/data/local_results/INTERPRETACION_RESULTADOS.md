# Resultados comprobados localmente · CSV aportado por el usuario

- **339 607 transacciones**; 19 columnas; sin valores nulos ni filas rechazadas con las reglas implementadas.
- `es_fraude=1`: **1 782** registros, **0,5247 %** de la muestra.
- `es_noche=1`: 1 530 de 79 502 transacciones (**1,9245 %**); `es_noche=0`: 252 de 260 105 (**0,0969 %**). Son tasas descriptivas y no prueba causal.
- `high_risk_cat=1`: 1 031 de 76 009 (**1,3564 %**); `high_risk_cat=0`: 751 de 263 598 (**0,2849 %**). `high_risk_cat` no identifica categoría comercial concreta.
- El campo `monto_winsorizado_99` es una variable procesada. **No** estimar pérdida financiera real, suma original ni moneda a partir de él.
- El archivo carece de timestamp y año; `mes` no permite inferir tendencias anuales.

Estos resultados son cálculos locales reproducibles. **No representan salidas de Athena, Spark AWS o Cost Explorer** hasta ejecutar los scripts con credenciales AWS.

Fuente: `data/real/fraude_tarjeta_credito_process.csv` (usuario); procedencia exacta relativa a Kaggle no auditada.
