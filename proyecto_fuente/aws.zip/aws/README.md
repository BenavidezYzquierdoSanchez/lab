# FRAUDCLOUD 2026 — Pipeline Big Data en AWS con el CSV REAL compartido

**Curso:** Big Data y Cloud Computing · **Sustentación:** 18–19 de noviembre de 2026 · **Estado:** código, dataset y pruebas locales listos; **AWS aún NO desplegado**.

## Datos verificados del archivo entregado

- Archivo: `data/real/fraude_tarjeta_credito_process.csv` (incluido, 54 012 105 bytes).
- Filas: **339 607**; 19 columnas; **0 campos vacíos y 0 filas inválidas** según reglas documentadas.
- Fraudes (`es_fraude=1`): **1 782**; operaciones no fraudulentas: **337 825**; tasa: **0,5247 %**.
- Verifique integridad con SHA-256: `3f7762e0f7c35824e00aeb91968a3fc724c6e2a2f87bfd1d6c37277977cba794`.
- Origen: CSV procesado **compartido por el usuario**. El usuario referenció https://www.kaggle.com/datasets/dhruvb2028/credit-card-fraud-dataset, pero no fue posible verificar su correspondencia exacta con dicho repositorio.
- **Limitación:** `monto_winsorizado_99` es un valor transformado/recortado, NO el monto monetario original. Se desconoce moneda; no usar los totales como pérdidas reales. No hay categorías comerciales descriptivas, año de operación ni timestamp original. `high_risk_cat` es una variable binaria.

## Arquitectura académica

```text
CSV del usuario → S3 raw/transactions/ → AWS Glue ETL Spark → S3 curated/transactions/ (Parquet Snappy)
                                                             ↓
                                                Glue Crawler + Data Catalog
                                                             ↓
                                                        Amazon Athena
                                                             ↓
                                               Streamlit (CSV Athena) / QuickSight opcional

Seguridad transversal: IAM rol mínimo para Glue, MFA del operador (configuración manual),
SSE-S3, TLS obligatorio, acceso público bloqueado, S3 Lifecycle y AWS Budgets.
```

**Actualización de compatibilidad:** se utiliza el nombre de catálogo `fraude_tarjetas_db` (con guiones bajos) porque Athena no admite normalmente bases de datos con guiones en su nombre. Consulte `GUIA_CONFIGURACION_AWS.md` para ejecutar el proyecto desde VS Code.

## Paso 0: requisitos

Instale **Python 3.10+**, AWS CLI v2 y configure una cuenta AWS con permisos para CloudFormation, Glue, S3, IAM, Athena y Budgets. Prevea costos (Glue Spark, crawler, consultas y recursos). Use IAM Identity Center/MFA; no claves en el proyecto.

```powershell
python -m pip install -r requirements.txt
aws sts get-caller-identity
```

## Paso 1: ejecutar y visualizar SIN AWS (datos reales)

Desde la carpeta del proyecto:

```powershell
python scripts/local_check.py --csv data/real/fraude_tarjeta_credito_process.csv
python -m pytest -q tests
python -m pip install -r dashboard/requirements.txt
python -m streamlit run dashboard/app.py
```

El dashboard ofrece **«Previsualización LOCAL — CSV del usuario»** desde `data/local_results/sql_preview/`. Los 8 CSV de esa carpeta **NO son salidas de Athena**. Los resultados de AWS van exclusivamente a `data/athena_results/`.

## Paso 2: desplegar recursos en AWS (costos reales)

Antes del deploy: `aws cloudformation validate-template --template-body file://infra/main.yaml --region us-east-1`. Si usa un perfil IAM Identity Center llamado `fraudlab`, en PowerShell ejecute `$env:AWS_PROFILE = "fraudlab"` para que boto3 y AWS CLI usen el mismo perfil.

Reemplace el correo por el suyo. El email debe confirmar las notificaciones de presupuesto cuando corresponda:

```powershell
python scripts/run_aws.py deploy --region us-east-1 --email correo@ejemplo.com --budget 5
```

`AWS Budgets` **avisa y no detiene el consumo**. La cuenta, región, tarifas y nivel gratuito deben verificarse en AWS. La política de mínimo privilegio del rol Glue está definida en CloudFormation; el operador del CLI debe tener sus propios permisos limitados y MFA.

## Paso 3: cargar el archivo procesado y ejecutar

```powershell
python scripts/run_aws.py upload --region us-east-1 --data data/real/fraude_tarjeta_credito_process.csv
python scripts/run_aws.py etl --region us-east-1
python scripts/run_aws.py catalog --region us-east-1
python scripts/run_aws.py queries --region us-east-1
```

- Carga el CSV real a S3 `raw/transactions/` y el script Glue a S3 `scripts/`.
- Glue limpia, valida y escribe 13 columnas analíticas sin edad exacta ni población de ciudad en formato Parquet.
- Crawler registra la tabla en Glue Data Catalog.
- Athena ejecuta **8 preguntas de negocio**, y `run_aws.py` descarga sus resultados a `data/athena_results/`.
- El dashboard detecta resultados de Athena y permite alternar la fuente, distinguiendo siempre AWS de la previa local.

Para recargar, primero elimine manualmente SOLO el objeto bajo `raw/transactions/` que pertenece al stack. El comando `upload` impide mezclar datasets en ese prefijo.

## Paso 4: evidencias de funcionamiento (pendientes en cuenta AWS)

Capturar: CloudFormation stack, S3 raw/curated, historial de Job Glue `SUCCEEDED`, crawler `SUCCEEDED`, tabla en Data Catalog, consulta Athena y resultado, vista del tablero, AWS Budgets y Cost Explorer. **Ninguna captura ni costo AWS se ha fabricado en la entrega.** Ver `evidencias/LEEME.md`.

## Paso 5: eliminar infraestructura con cuidado

```powershell
python scripts/run_aws.py destroy --region us-east-1 --confirm-destroy
```

**Atención:** destruye todos los objetos dentro del bucket que creó el stack y luego el stack. Revise recursos que pudieran existir fuera de CloudFormation y la facturación después.

## Archivos destacados

- `infra/main.yaml`: infraestructura como código CloudFormation.
- `glue/glue_etl.py`: transformación Spark específica de las **19 columnas reales**, salida Parquet.
- `sql/01..08_*.sql`: 8 consultas Athena consistentes con campos reales.
- `scripts/run_aws.py`: orquestador de despliegue, subida, ETL, catálogo, SQL y borrado.
- `scripts/local_check.py`: validación exhaustiva y agregados locales reproducibles.
- `data/real/ORIGEN_Y_DICCIONARIO.md`: diccionario y advertencias de procedencia.
- `data/local_results/`: resumen, 8 vistas locales, auditoría SHA-256.
- `dashboard/app.py`: panel Streamlit con comparaciones por segmentos.
- `docs/informe_tecnico.pdf` y `docs/presentacion_sustentacion.pptx`: documentos actualizados con resultados verificados del CSV.
- `diagrams/arquitectura.drawio`: diagrama editable del pipeline.
- `docs/presupuesto_costos.csv` y guías de Cost Explorer/QuickSight/seguridad.

## Marco de interpretación

Es un **análisis descriptivo observacional** de registros transformados. La asociación entre noche, categorías de alto riesgo y fraude **no prueba causalidad**; las etiquetas y transformaciones deben auditarse con la fuente original antes de cualquier decisión automatizada. No hay entrenamiento de modelos ni predicción transaccional en línea.
