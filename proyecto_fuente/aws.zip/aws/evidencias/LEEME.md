# Evidencias que faltan: realizar en tu propia cuenta AWS

- [ ] Cuenta/rol IAM para laboratorio, MFA habilitado (ocultar datos privados).
- [ ] AWS Budgets: presupuesto de alerta, correo y confirmación.
- [ ] CloudFormation: stack creado.
- [ ] S3 RAW: archivo `fraude_tarjeta_credito_process.csv` y permisos; tamaño y fecha.
- [ ] Glue Job `SUCCEEDED`: registrar logs con 339 607 filas RAW, 339 607 válidas y 0 rechazadas si se usa exactamente este CSV sin cambios.
- [ ] S3 CURATED: partición `ingest_date=...` con archivos Parquet.
- [ ] Crawler `SUCCEEDED` y tabla creada en catálogo Glue.
- [ ] Athena: por lo menos 3 consultas SQL de las 8 incluidas y sus resultados reales.
- [ ] Dashboard: fuente «Resultados REALES de Athena» o QuickSight, indicando costo/edición.
- [ ] AWS Pricing Calculator y Cost Explorer: pantalla de cotización y gasto real (puede ser 0 si no hay cargos).
- [ ] Limpieza de recursos, si corresponde.

`data/local_results/sql_preview/` es una **previsualización local** y NO cuenta como evidencia Glue/Athena. No insertar capturas inventadas en informe o sustentación.
