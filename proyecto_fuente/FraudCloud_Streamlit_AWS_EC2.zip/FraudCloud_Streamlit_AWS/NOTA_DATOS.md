# Protección de datos

Este paquete NO contiene el CSV RAW original de 339 607 registros ni credenciales AWS.
Contiene solamente agregados para previsualización local. Para datos actuales y verificables, debe sincronizar con Athena mediante la función de despliegue y el rol IAM limitado.

El dashboard no es una herramienta de decisión antifraude en tiempo real; muestra análisis descriptivos del conjunto procesado.
