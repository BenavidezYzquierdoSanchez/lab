#!/usr/bin/env bash
# EC2 Ubuntu 24.04: instalar y arrancar FraudCloud Streamlit como servicio.
set -euo pipefail
if [[ "$EUID" -ne 0 ]]; then echo 'Ejecute: sudo bash deploy/instalar_ubuntu.sh'; exit 1; fi
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip ca-certificates
if ! id fraudcloud >/dev/null 2>&1; then
  useradd --system --create-home --home-dir /opt/fraudcloud --shell /usr/sbin/nologin fraudcloud
fi
mkdir -p /opt/fraudcloud
cp -a "$SRC/." /opt/fraudcloud/
python3 -m venv /opt/fraudcloud/.venv
/opt/fraudcloud/.venv/bin/python -m pip install --upgrade pip
/opt/fraudcloud/.venv/bin/python -m pip install -r /opt/fraudcloud/dashboard/requirements.txt
chown -R fraudcloud:fraudcloud /opt/fraudcloud
cat > /etc/systemd/system/fraudcloud.service <<'UNIT'
[Unit]
Description=FraudCloud Streamlit Dashboard
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
User=fraudcloud
Group=fraudcloud
WorkingDirectory=/opt/fraudcloud
Environment=AWS_DEFAULT_REGION=us-east-1
Environment=STREAMLIT_BROWSER_GATHER_USAGE_STATS=false
ExecStart=/opt/fraudcloud/.venv/bin/python -m streamlit run /opt/fraudcloud/dashboard/app.py --server.address=0.0.0.0 --server.port=8501 --server.headless=true --server.enableCORS=true --server.enableXsrfProtection=true
Restart=always
RestartSec=4
NoNewPrivileges=true
ProtectSystem=full
PrivateTmp=true
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now fraudcloud.service
echo 'FraudCloud iniciado. Estado:'
systemctl is-active fraudcloud
printf '\nIMPORTANTE: abra TCP 8501 solo desde su IP en el Security Group EC2.\n'
printf 'Para datos reales: sudo -u fraudcloud /opt/fraudcloud/.venv/bin/python /opt/fraudcloud/deploy/actualizar_athena.py\n'
