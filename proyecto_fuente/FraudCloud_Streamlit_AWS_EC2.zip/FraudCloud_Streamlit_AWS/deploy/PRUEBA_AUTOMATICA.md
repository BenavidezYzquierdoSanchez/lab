# Comprobaciones antes de publicar

* Ejecutar `python -m py_compile dashboard/app.py deploy/actualizar_athena.py`.
* Verificar que los ocho SQL existen y que `sql/01_kpis_fraude.sql` contiene los cuatro KPI.
* En EC2: `sudo systemctl status fraudcloud --no-pager`.
* Ejecutar `sudo -u fraudcloud /opt/fraudcloud/.venv/bin/python /opt/fraudcloud/deploy/actualizar_athena.py` (consulta real, genera costos).
* Confirmar `ls -la /opt/fraudcloud/data/athena_results/` contiene ocho CSV y `_metadata.json`.
* Acceder a `http://IP_PUBLICA_EC2:8501` desde IP autorizada.
* Confirmar modo por defecto «Resultados REALES de Athena — AWS» y los KPI 339 607, 1 782, 337 825 y 0,5247 %.
* Comprobar AWS Budgets y cerrar EC2 al terminar la presentación.
