# FraudCloud 2026 — Dashboard Streamlit en Amazon EC2 (AWS)

Esta es una adaptación del dashboard ORIGINAL del proyecto. Mantiene los gráficos e indicadores y agrega la posibilidad de **actualizar las 8 vistas reales desde Amazon Athena** directamente en la EC2.

**No se ha desplegado una instancia EC2 ni ejecutado una consulta AWS desde este paquete.** Es un paquete listo para instalar y probar en TU cuenta; el funcionamiento real depende de permisos IAM, red y recursos existentes.

## 1) Crear servidor EC2 desde consola AWS

1. AWS → EC2 → Launch instance; región **US East (N. Virginia) `us-east-1`** (no confundir con Ohio `us-east-2`, que es la región de IAM Identity Center).
2. Nombre `fraudcloud-streamlit-2026`; Ubuntu Server **24.04 LTS**; arquitectura **x86_64**; tipo `t3.small` o equivalente compatible (es de pago según cuenta/uso). Disco raíz mínimo 12 GiB.
3. Generar clave SSH `.pem` y guardarla en Windows con permisos restrictivos. Habilitar IPv4 pública si la instancia se conectará por Internet.
4. Security group: permitir SSH TCP 22 **solo desde «Mi IP»**; permitir Custom TCP 8501 **solo desde «Mi IP»**. No publicar el 8501 a todo Internet ni subir transacciones originales. La URL de prueba inicial usa HTTP, por eso no debe compartir datos sensibles ni claves.
5. En IAM → Roles → Crear rol: servicio **EC2**, nombre sugerido `FraudCloud-EC2-Athena`. Adjuntar política inline del archivo `deploy/politica_permisos_athena_ec2.json`. Vincularlo en la creación de EC2 o luego en EC2 → Acciones → Seguridad → Modificar rol de IAM. **No cree access keys ni copie credenciales IAM Identity Center a EC2**.
6. Este rol de ejemplo está limitado a la cuenta `239635360641`, región `us-east-1`, workgroup `fraude-tarjetas-wg`, base `fraude_tarjetas_db` y bucket `fraude-tarjetas-239635360641-us-east-1`. Verificar que esos recursos aún existan y ajustarlos si cambiaron.

## 2) Subir ZIP desde Windows PowerShell

Descargue el ZIP del chat y colóquelo en Descargas; reemplace la IP y el nombre de la clave por los reales. Ejecute:

```powershell
scp -i "C:\ruta\mi-clave-aws.pem" "$env:USERPROFILE\Downloads\FraudCloud_Streamlit_AWS_EC2.zip" ubuntu@IP_PUBLICA_EC2:~
ssh -i "C:\ruta\mi-clave-aws.pem" ubuntu@IP_PUBLICA_EC2
```

## 3) Instalar servicio (terminal Ubuntu EC2)

```bash
sudo apt-get update && sudo apt-get install -y unzip
unzip -o FraudCloud_Streamlit_AWS_EC2.zip
sudo bash FraudCloud_Streamlit_AWS/deploy/instalar_ubuntu.sh
sudo systemctl status fraudcloud --no-pager
```

La aplicación arranca automáticamente y responde al puerto **8501**. Desde su Windows con IP autorizada, entre en:

```
http://IP_PUBLICA_EC2:8501
```

Al principio verá previsualización **LOCAL**. No afirmar que esos valores se calcularon en EC2 o Athena.

## 4) Obtener los 8 CSV auténticos desde AWS Athena

Al tener el rol IAM correctamente unido a EC2, en SSH ejecute:

```bash
sudo -u fraudcloud /opt/fraudcloud/.venv/bin/python /opt/fraudcloud/deploy/actualizar_athena.py \
  --region us-east-1 \
  --bucket fraude-tarjetas-239635360641-us-east-1 \
  --database fraude_tarjetas_db \
  --table fraud_transactions \
  --workgroup fraude-tarjetas-wg
```

El programa lanza los **ocho SQL** del proyecto en Athena, espera resultados, descarga los CSV desde S3 y deja un `data/athena_results/_metadata.json` con la fecha. **Estas consultas tienen costo**; ejecute solo cuando necesite actualizar, no en cada visita.

Refresque el navegador (F5). El dashboard mostrará por defecto **«Resultados REALES de Athena — AWS»** y los ocho gráficos. Los KPI esperados para el conjunto ya validado son **339 607**, **1 782**, **337 825** y **0,5247 %**. Si difieren, verifique que la tabla corresponde al CSV correcto.

### Si el rol EC2 todavía no se encuentra listo

Es posible exportar los resultados Athena a partir del proyecto original en Windows con:

```powershell
aws sso login --profile fraudlab
$env:AWS_PROFILE = 'fraudlab'
python scripts/run_aws.py queries --region us-east-1
```

Después deberá transferir los ocho CSV originales de `data/athena_results/` a `/opt/fraudcloud/data/athena_results/` del servidor (SCP). Evite incluir el CSV RAW completo o claves AWS en la carpeta pública.

## 5) Diagnóstico

```bash
sudo systemctl status fraudcloud --no-pager
sudo journalctl -u fraudcloud -n 60 --no-pager
sudo ss -lntp | grep 8501
ls -lh /opt/fraudcloud/data/athena_results
```

* Si falla `AccessDenied`: revise rol de instancia, política IAM, S3/KMS y workgroup Athena. Las políticas del ZIP son base, no sustituyen restricciones adicionales de cuenta.
* Si falla `TABLE_NOT_FOUND`: revisar Glue Data Catalog y base `fraude_tarjetas_db` en `us-east-1`.
* Si carga solo la previsualización local: ejecute `actualizar_athena.py` en EC2 y confirme ocho CSV en `data/athena_results/`.
* Si no abre el navegador: confirme EC2 `running`, IPv4 pública, entrada TCP 8501 en SG limitada a su IP, firewall Ubuntu, y `systemctl` activo.
* Si cambia de red o de IP pública, ajuste el Security Group antes de conectarse.

## 6) Seguridad, presentación y costos

* La aplicación no tiene autenticación propia; la demo es solo para un origen IP confiable. Para publicación pública permanente, use HTTPS, dominio, autenticación y reverse proxy/load balancer antes de habilitar acceso global.
* **No** use el rol `AdministratorAccess` de tu usuario SSO como rol de ejecución EC2; otorgue solo permisos del proyecto.
* **No** instale una nueva NAT Gateway para esta app. Revise las dos NAT Gateways de prácticas anteriores, que pueden generar gastos incluso sin tráfico.
* Revisar AWS Budgets y confirmar email de alertas; un presupuesto no corta automáticamente los recursos.
* Al finalizar la sustentación, detener o eliminar EC2 según se necesite; las NAT Gateways y otros recursos del laboratorio deben limpiarse por separado, con atención a dependencias.
* EC2 encendido, almacenamiento EBS, IPv4 pública y consultas Athena pueden generar cargos.

**Archivos:** `dashboard/app.py` aplicación original adaptada; `sql/` consultas; `data/local_results/` previsualización claramente marcada; `deploy/instalar_ubuntu.sh` servicio y dependencias; `deploy/actualizar_athena.py` sincroniza ocho resultados reales; `deploy/politica_permisos_athena_ec2.json` IAM de ejemplo.
