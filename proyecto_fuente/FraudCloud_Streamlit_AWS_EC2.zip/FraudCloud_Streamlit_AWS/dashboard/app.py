"""Dashboard profesional: resultados de Athena o previsualización local separada.

Los datos locales provienen de scripts/local_check.py; NO son un despliegue AWS.
"""
from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st

ROOT=Path(__file__).resolve().parents[1]
ATHENA=ROOT/'data'/'athena_results'
LOCAL=ROOT/'data'/'local_results'/'sql_preview'

st.set_page_config(page_title='FraudCloud | AWS Big Data',page_icon='💳',layout='wide')
st.markdown('''
<style>
.block-container {padding-top:1.4rem; max-width:1400px}
h1 {letter-spacing:-1px; font-weight:800}
div[data-testid="stMetric"] {background:linear-gradient(135deg,#f3f8ff,#fff);border:1px solid #dce7f3;border-radius:15px;padding:15px}
[data-testid="stMetricLabel"] {font-size:.95rem}
</style>''',unsafe_allow_html=True)
st.title('💳 FraudCloud · Inteligencia de transacciones')
st.caption('Big Data y Cloud Computing · S3 → Glue ETL (Parquet) → Glue Data Catalog → Athena')

options=[]
if LOCAL.exists() and (LOCAL/'01_kpis_fraude.csv').exists():
    options.append('Previsualización LOCAL — CSV del usuario')
if ATHENA.exists() and (ATHENA/'01_kpis_fraude.csv').exists():
    options.append('Resultados REALES de Athena — AWS')
if not (ATHENA/'01_kpis_fraude.csv').exists():
    st.info('El despliegue AWS todavía no tiene consultas Athena sincronizadas. Ejecute deploy/actualizar_athena.py en EC2 con un rol IAM de lectura de resultados y ejecución de consultas.')
if not options:
    st.error('No se encontraron resultados. Ejecute deploy/actualizar_athena.py para consultar el catálogo AWS o copie resultados reales a data/athena_results/.')
    st.stop()
choice=st.selectbox('Origen de los datos visualizados',options,index=options.index('Resultados REALES de Athena — AWS') if 'Resultados REALES de Athena — AWS' in options else 0)
folder=ATHENA if choice.startswith('Resultados') else LOCAL
if folder==LOCAL:
    st.warning('Modo local: agregaciones calculadas sobre el CSV recibido. NO son consultas ejecutadas en Athena ni evidencias de un despliegue AWS.',icon='⚠️')
else:
    st.success('Resultados agregados de consultas reales de Amazon Athena (AWS).')
    metadata_path=ATHENA/'_metadata.json'
    if metadata_path.exists():
        import json
        metadata=json.loads(metadata_path.read_text(encoding='utf-8'))
        st.caption('Sincronización AWS: '+metadata.get('synced_at_utc','fecha no disponible')+' UTC · Región: '+metadata.get('region','desconocida'))

@st.cache_data(show_spinner=False)
def load(path, stamp):
    return pd.read_csv(path)

def read(n):
    hits=sorted(folder.glob(n+'*.csv'))
    return load(hits[0],hits[0].stat().st_mtime_ns) if hits else pd.DataFrame()

k,monto,noche,riesgo,edad,mes,finsem,distancia=(read(n) for n in ('01_','02_','03_','04_','05_','06_','07_','08_'))
if k.empty:
    st.error('Falta el KPI 01'); st.stop()
r=k.iloc[0]
col=st.columns(4)
col[0].metric('Transacciones analizadas',f'{int(r.total_transacciones):,}'.replace(',',' '))
col[1].metric('Fraudes identificados',f'{int(r.transacciones_fraude):,}'.replace(',',' '))
col[2].metric('Tasa de fraude',f'{r.tasa_fraude_pct:.4f} %')
col[3].metric('Operaciones legítimas',f'{int(r.transacciones_legitimas):,}'.replace(',',' '))
st.caption('Monto: variable `monto_winsorizado_99` (recortada estadísticamente). No se conoce la moneda ni la suma monetaria original; no se interpreta como pérdida financiera real.')

charttype=st.radio('Métrica a comparar',['Tasa de fraude (%)','Cantidad de fraudes'],horizontal=True)
y='tasa_fraude_pct' if charttype.startswith('Tasa') else 'fraudes'

def showbar(df,x,title,caption,mapping=None):
    if df.empty:return
    d=df.copy()
    if mapping:
        d[x]=d[x].map(mapping).fillna(d[x].astype(str))
    else:
        d[x]=d[x].astype(str)
    st.subheader(title)
    fig=px.bar(d,x=x,y=y,text=y,color=y,color_continuous_scale=['#bcd1ef','#1d4e89'],labels={y:charttype,x:''})
    fig.update_traces(texttemplate='%{text:.3f}' if y=='tasa_fraude_pct' else '%{text:.0f}', textposition='outside')
    fig.update_layout(height=330,margin=dict(t=14,b=20),coloraxis_showscale=False)
    st.plotly_chart(fig,width="stretch")
    st.caption(caption)

left,right=st.columns(2,gap='large')
with left:
    showbar(noche,'es_noche','Fraudes: noche frente a día','Variable binaria ya procesada; asociación descriptiva, no causalidad.',{0:'No nocturna',1:'Nocturna'})
    showbar(edad,'edad_grupo','Fraudes por grupo de edad','La tasa por grupo evita confundir frecuencia con riesgo relativo.')
    showbar(finsem,'es_fin_de_semana','Fraudes y fin de semana','El CSV provee el indicador de fin de semana.',{0:'Día laboral',1:'Fin de semana'})
with right:
    showbar(riesgo,'high_risk_cat','Bandera de categoría de riesgo','`high_risk_cat` es 0/1, no una categoría comercial identificable.',{0:'Riesgo no marcado',1:'Categoría marcada'})
    showbar(monto,'rango_monto','Monto winsorizado por rangos','Grupos del campo procesado, no importes originales de tarjeta.')
    showbar(distancia,'rango_distancia','Distancia cliente-comercio','Tramos descriptivos en kilómetros (atributo derivado).')
if not mes.empty:
    st.subheader('Comportamiento por mes disponible')
    f=px.line(mes,x='mes',y=y,markers=True,labels={'mes':'Mes (sin año)',y:charttype})
    f.update_layout(height=315,margin=dict(t=10,b=25))
    st.plotly_chart(f,width="stretch")
    st.caption('El archivo no contiene año; NO es una serie temporal cronológica ni demuestra cambios interanuales.')
with st.expander('Ver registros agregados y advertencias de análisis'):
    st.dataframe(k,width="stretch",hide_index=True)
    st.dataframe(noche,width="stretch",hide_index=True)
    st.write('**Limitaciones:** datos preprocesados; fuente Kaggle declarada no verificada; clase muy desbalanceada; etiquetas derivadas sin procedimiento original; sin ID transaccional, moneda, marca temporal completa o negocio.')
st.divider()
st.caption('Proyecto académico analítico batch. No predice fraude, no identifica personas ni supone uso productivo en pagos.')
